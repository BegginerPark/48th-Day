import java.util.*;

class Main {
  public static void main(String[] args) {
    //6-9,6-14
    Data d = new Data();
    d.x = 10;

    Data d2 = copy(d);
    System.out.println("d.x = " +d.x);
    System.out.println("d2.x = " + d2.x);
    // System.out.println("main() : x = " + d.x);

    // change(d.x);
    // System.out.println("After change(d.x)");
    // System.out.println("main(): x = " + d.x);


  }
  //6-9
  // static void change(int x) {
  //   x = 1000;
  //   System.out.println("change() : x = " + x);
  // }

  //6-14
  static Data copy(Data d) {
    Data tmp = new Data();
    tmp.x = d.x;

    return tmp;
  }
}

//6-9
class Data {
  int x;
}